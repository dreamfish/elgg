<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
		* @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Boris Glumpler
	 * @copyright Boris Glumpler 2008
	 * @link /travel-junkie.com
	 */

	function customindex_init() {

		register_plugin_hook('index','system','new_index');		
		register_page_handler('dashboard','new_dashboard');

	}

    function new_dashboard($page) {
		customindex_fetchpage(array('MemberDashboard'));
    }

	function new_index() {
		//if (!@include_once(dirname(dirname(__FILE__))) . "/customindex/index.php") return false;
		//return true;
		customindex_fetchpage(array('Home'));
		return true;
	}

	function customindex_fetchpage($page) {
		$body = "";
		switch ($page[0]) 
		{
			case "login":
				$body = elgg_view("account/forms/login");
			break;
			case "MemberDashboard":
				$body = '';
				$pages = search_for_object('DFADMIN_'.'MemberDashboard');
				if ($pages && sizeof($pages) > 0) {
					$body .= $pages[0]->description;
				} 
			
				//clear existing widgets
				$area1widgets = get_widgets(page_owner(),'dashboard',1);
				foreach($area1widgets as $widget) {
					$widget->delete();
				}
				
				//save widgets
				$widgettypes = get_widget_types();	
				foreach($widgettypes as $handler => $widget) {
					$guid = $_SESSION['guid'];					
					//add_widget ( $guid, $handler, 'dashboard', $i, 1 );
					//echo "<!--" . $handler . "-->";
					$i = $i + 1;				
				}
				
				$guid = $_SESSION['guid'];					
				add_widget ( $guid, 'river_widget', 'dashboard', 1, 1 );				
				add_widget ( $guid, 'a_users_groups', 'dashboard', 2, 1 );
				add_widget ( $guid, 'bookmarks', 'dashboard', 3, 1 );
				add_widget ( $guid, 'tasks', 'dashboard', 4, 1 );
				
				//display widgets
				$area1widgets = get_widgets(page_owner(),'dashboard',1);
				foreach($area1widgets as $widget) {
					$body .= elgg_view_entity($widget);
				}
				//$body = elgg_view_layout('widgets',"","",'foo');
			break;
			default:
				$pages = search_for_object('DFADMIN_'.$page[0]);
				if ($pages && sizeof($pages) > 0) {
					$body .= $pages[0]->description;
				} else
				{
					$body = $page[0] . ' does not exist';		
				}

				
		}
		$content = elgg_view_layout('one_column', $body);
		echo page_draw(null, $content);
		
	}
	register_elgg_event_handler('init','system','customindex_init');
	register_page_handler('page', 'customindex_fetchpage');
?>
